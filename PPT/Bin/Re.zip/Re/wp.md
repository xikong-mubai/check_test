# Re

## [2019红帽杯]xx

64exe，从youwin找到关键函数

加密可分为三个部分，

![xx-1](./img/1770991-20200516163405377-1699664350.png)

![xx-2](./img/1770991-20200516163434369-417808555.png)

此处可看出是一个xxtea，之后

![xx-3](./img/1770991-20200516163523961-903565052.png)

对位置进行了变换，

![xx-4](./img/1770991-20200516163614063-487119396.png)

按一定规律进行了异或，最终得到的结果与

![xx-5](img/1770991-20200516163706805-1731002927.png)

对比，思路就是从后往前推回去

```python
# -*- coding:utf-8 -*-
v18=[0xce,0xbc,0x40,0x6b,0x7c,0x3a,0x95,0xc0,0xef,0x9b,0x20,0x20,0x91,0xf7,0x02,0x35,0x23,0x18,0x02,0xc8,0xe7,0x56,0x56,0xfa]
v19=[]
for i in range(24):
    v19.append(0)
for i in range(len(v18)-1,-1,-1):
    if i>=3:
        for j in range(i//3):
            v18[i]^=v18[j]
print(v18)
v19[2] = v18[0]
v19[0] = v18[1];
v19[3] = v18[2];
v19[1] = v18[3];
v19[6] = v18[4];
v19[4] = v18[5];
v19[7] = v18[6];
v19[5] = v18[7];
v19[10] = v18[8];
v19[8] = v18[9];
v19[11] = v18[10];
v19[9] = v18[11];
v19[14] = v18[12];
v19[12] = v18[13];
v19[15] = v18[14];
v19[13] = v18[15];
v19[18] = v18[16];
v19[16] = v18[17];
v19[19] = v18[18];
v19[17] = v18[19];
v19[22] = v18[20];
v19[20] = v18[21];
v19[23] = v18[22];
v19[21] = v18[23]
print(v19)
for i in range(len(v19)):
    v19[i]=hex(v19[i])
print(v19)
```

得到的结果进行xxtea解密，此处来自于TEA、XTEA、XXTEA加密解密算法

```c++
#include <stdio.h>
#include <stdint.h>
#define DELTA 0x9e3779b9
#define MX (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))
void btea(uint32_t* v, int n, uint32_t const key[4])
{
    uint32_t y, z, sum;
    unsigned p, rounds, e;
    if (n > 1)            /* Coding Part */
    {
        rounds = 6 + 52 / n;
        sum = 0;
        z = v[n - 1];
        do
        {
            sum += DELTA;
            e = (sum >> 2) & 3;
            for (p = 0; p < n - 1; p++)
            {
                y = v[p + 1];
                z = v[p] += MX;
            }
            y = v[0];
            z = v[n - 1] += MX;
        } while (--rounds);
    }
    else if (n < -1)      /* Decoding Part */
    {
        n = -n;
        rounds = 6 + 52 / n;
        sum = rounds * DELTA;
        y = v[0];
        do
        {
            e = (sum >> 2) & 3;
            for (p = n - 1; p > 0; p--)
            {
                z = v[p - 1];
                y = v[p] -= MX;
            }
            z = v[n - 1];
            y = v[0] -= MX;
            sum -= DELTA;
        } while (--rounds);
    }
}
int main()
{
    uint32_t v[6] = {0x40cea5bc,0xe7b2b2f4,0x129d12a9,0x5bc810ae,0x1d06d73d,0xdcf870dc};
    uint32_t const k[4] = { 0x67616c66,0x0,0x0,0x0 };
    int n = 6;
    btea(v, -n, k);
    printf("解密后的数据：%x %x %x %x %x %x
", v[0], v[1],v[2],v[3],v[4],v[5]);
    return 0;
}
```

## [GWCTF 2019]xxor

比较简单，就是Tea加密变种
Tea加密可以到ctfwiki学习，解密原理是逆向求解
解密最好用c语言写，python写有点麻烦

## drinkSomeTea

看到题目盲猜一波TEA加密，果不其然。之前没好好学，这次至少会做题了，之后有空要好好再看看详细的加密流程。附件给了个tea.png.out，即需要解密图片。
32位exe，无壳

![dST-1](./img/1616848097038-02fff004-ac11-4a64-b153-f011afb64fec.png)

在一开始的sub_401000函数里面，应该是判断是不是调试器（我没仔细看），用调试器的时候会退出程序，直接把call sub_401000 nop掉即可。

![dST-2](./img/1616847245371-f690b22b-eb35-472f-b101-801360db52c5.png)

应该是一个加密函数，点进去看发现加花了

![dST-3](./img/1616847425525-257970be-f093-48ad-aa31-d7f7a1f068cf.png)

去花，Create Function，F5，发现是TEA加密

![dST-4](./img/1616847475073-d4a5223c-642f-4eb2-8f3f-dc93731a9718.png)

魔改一下TEA加密即可，要注意的是，加密的时候需要用int指针（保留符号位），否则加密/解密出来的数据会不对。（我在这个地方调了很久，照着还原一次加密过程，动调的时候发现加密出来的数据怎么都不对）
最后用解密函数解密tea.png.out，脚本如下:

```c++
#include <iostream>
#include <stdio.h>
#include<Windows.h>
 
void encrypt(int* v, uint32_t* k) {
    int v0 = v[0], v1 = v[1], sum = 0, i;           /* set up */
    int delta = 0x61C88647;                     /* a key schedule constant */
    int k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];   /* cache key */
    for (i = 0; i < 32; i++) {                       /* basic cycle start */
        sum -= delta;
        v0 += ((v1 >> 5) + k1) ^ (v1 + sum) ^ ((v1 << 4) + k0);
        v1 += ((v0 >> 5) + k3) ^ (v0 + sum) ^ ((v0 << 4) + k2);
    }                                              /* end cycle */
    v[0] = v0; v[1] = v1;
}
 
void decrypt(int* v, uint32_t* k) {
    int v0 = v[0], v1 = v[1], sum = 0xC6EF3720, i;  /* set up */
    int delta = 0x61C88647;                     /* a key schedule constant */
    int k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];   /* cache key */
    for (i = 0; i < 32; i++) {                         /* basic cycle start */
        v1 -= ((v0 >> 5) + k3) ^ (v0 + sum) ^ ((v0 << 4) + k2);
        v0 -= ((v1 >> 5) + k1) ^ (v1 + sum) ^ ((v1 << 4) + k0);
        sum += delta;
    }                                              /* end cycle */
    v[0] = v0; v[1] = v1;
}
 
int main()
{
    DWORD key[4] = { 0x67616C66, 0x6B61667B, 0x6C665F65, 0x7D216761 };
    HANDLE file = CreateFileA("tea.png.out", 0xC0000000, 0, 0, 3u, 0x80u, 0);
    HANDLE v4 = file;
    char *v7;
    DWORD v8;
    HANDLE v9;
    void *v10;
    DWORD NumberOfBytesRead;
    DWORD NumberOfBytesWritten;
    DWORD v6 = GetFileSize(file, 0);
    DWORD dword_409988[15000];
    if (v6 < 0xEA60)
    {
        SetFilePointer(v4, 0, 0, 0);
        NumberOfBytesRead = 0;
        ReadFile(v4, &dword_409988, v6, &NumberOfBytesRead, 0);
        CloseHandle(v4);
        if (v6 >> 3)
        {
            v7 = (char *)&dword_409988;
            v8 = v6 >> 3;
            do
            {
                decrypt((int *)v7, (uint32_t *)key);
                v7 += 8;
                --v8;
            } while (v8);
        }
        v9 = CreateFileA("tea.png", 0xC0000000, 0, 0, 2u, 0x80u, 0);
        v10 = v9;
        NumberOfBytesWritten = 0;
        WriteFile(v9, &dword_409988, v6, &NumberOfBytesWritten, 0);
        CloseHandle(v10);
    }
}
```

## Enjoyit-1

附件用ExEinfoPE可以看到

![DAS-2021-3-En-1](img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI0ODc2LTM2MTkyNzA4OC5wbmc=.png)

说明是.NET逆向，于是用ILSpy打开。

![DAS-2021-3-En-2](img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI1MTkwLTExNjAwNTk3NDAucG5n.png)

看到不寻常字符串DotfuscatorAttribute，用搜索引擎一查可以发现是使用Dotfuscator加密混淆程序的产物（[使用Dotfuscator加密混淆程序以及如何脱壳反编译_qwsf01115的专栏-CSDN博客](https://blog.csdn.net/qwsf01115/article/details/71425296)）。

所以根据文章指引用de4dot（可用release：[Release de4dot mod · CodingGuru1989/de4dot](https://github.com/CodingGuru1989/de4dot/releases/tag/snapshot)）进行反混淆，得到Enjoyit-1-cleaned.exe，再用ILSpy打开，就可以看到混淆前在Class0里的main函数。

![DAS-2021-3-En-3](img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI1NDU5LTI3MDc1MzY2NS5wbmc=.png)

这个逻辑也很简单，无非就是输入text正确以后运行100000秒就会输出flag。

（当然肯定不可能这么走啊，100000s=1666.67min=27.78h，必然是等不起的。

![DAS-2021-3-En-4](img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI1NzIwLTc3NzY2NzUyMS5wbmc=.png)

flag产生的逻辑是先用uint_和text进行method_3()的处理，然后再与array3按字节异或。

而text相当于是已知的，关键在 method_1()这里。

![DAS-2021-3-En-5](img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI2MDMwLTQ2ODUwNjk5Ny5wbmc=.png)

可以看出是一个base64换表，Table在string_0这里：

![DAS-2021-3-En-6](./img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI2Mzg1LTE4MjUwMzMzNzcucG5n.png)

于是可以先写脚本得到text：

```python
import base64
from binascii import *
src='yQXHyBvN3g/81gv51QXG1QTBxRr/yvXK1hC='
table='abcdefghijklmnopqrstuvwxyz0123456789+/ABCDEFGHIJKLMNOPQRSTUVWXYZ'
b64table='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
text=base64.b64decode(src.translate(str.maketrans(table,b64table)).encode())
print(text)
# text=b'combustible_oolong_tea_plz'
```

然后在主函数往下看，来到了第二个关键函数method_3()：

![DAS-2021-3-En-7](./img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI2NTk5LTk5OTQ5MzQ4MC5wbmc=.png)

显而易见是个改了delta的XTEA加密，传进来的uint_0是主函数的uint_，byte_0是text的前四字节。

写个脚本解一下,得到XTEA加密后的uint_：

```c++
#include <stdio.h>
#include <stdint.h>
/* take 64 bits of data in v[0] and v[1] and 128 bits of key[0] - key[3] */
void encipher(unsigned int num_rounds, uint32_t v[2], uint32_t const key[4]) {
    unsigned int i;
    uint32_t v0=v[0], v1=v[1], sum=0, delta=2654435464;
    for (i=0; i < num_rounds; i++) {
        v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]);
        sum += delta;
        v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11) & 3]);
    }
    v[0]=v0; v[1]=v1;
}
void decipher(unsigned int num_rounds, uint32_t v[2], uint32_t const key[4]) {
    unsigned int i;
    uint32_t v0=v[0], v1=v[1], delta=2654435464, sum=delta*num_rounds;
    for (i=0; i < num_rounds; i++) {
        v1 -= (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11) & 3]);
        sum -= delta;
        v0 -= (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]);
    }
    v[0]=v0; v[1]=v1;
}
int main()
{
    uint32_t v[2]={288,369};
    uint32_t const k[4]={0x63,0x6f,0x6d,0x62};
    unsigned int r=32;
    encipher(r, v, k);
    printf("%8x%8x\n",v[0],v[1]);
    return 0;
}
```

因为主函数里后续处理是把8 bit十六进制的两个结果往str里填，所以输出采用十六进制形式。

![DAS-2021-3-En-8](img/L3Byb3h5L2h0dHBzL2ltZzIwMjAuY25ibG9ncy5jb20vYmxvZy8yMTgzMTIyLzIwMjEwNC8yMTgzMTIyLTIwMjEwNDAxMTYxNTI2ODE0LTExNTU3ODYzMzAucG5n.png)

得到str="6308fe34b7fe6fdb"

最后进行xor处理即可，上exp：

```python
xtea="6308fe34b7fe6fdb"
arr3=[2,5,4,13,3,84,11,4,87,3,86,3,80,7,83,3,0,4,83,94,7,84,4,0,1,83,3,84,6,83,5,80]
flag=""
for i in range(len(arr3)):
    flag+=chr(arr3[i]^ord(xtea[i%len(xtea)]))
print("flag{"+flag+"}")
```
